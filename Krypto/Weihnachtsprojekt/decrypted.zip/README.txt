Die Alt-Klausuren bis einschließlich WS10/11 sind veraltet und repräsentieren möglicherweise NICHT den aktuellen Umfang und Inhalt der EK1-Klausur. 
Deswegen nochmals der Hinweis, dass nur Inhalte, die in der aktuellen Vorlesung abgedeckt wurden, klausurrelevant sind. 
Dennoch sind Teile der Alt-Klausuren sicherlich nützlich für die persönliche Klausurvorbereitung. Wir stellen die Klausuren deshalb für Interessierte zur Verfügung. 
